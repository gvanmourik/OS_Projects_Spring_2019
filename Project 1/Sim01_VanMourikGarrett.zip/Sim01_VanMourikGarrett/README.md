To build:
	1) "mkdir build"
	2) "cd build"
	3) "cmake ../"
	4) make

To run test: [from the build directory]
	1) "./bin/sim01 ../src/testConfig.conf"

Notes:
	1) The log file is saved to build/
	2) The test config file is located in src/