#ifndef META_IO
#define META_IO

#include <vector>
#include <sstream>
#include <fstream>
#include <iostream>
#include <type_traits>

#include "Stream.h"
#include "ConfigData.h"
#include "MetaData.h"

#define UNASSIGNED "NAH"

class MetaIO 
{
private:
	bool startFlag = false;
	std::string FilePath;
	std::vector<MetaData> FileData;


public:
	/// Constructors
	MetaIO(std::string _filePath) : FilePath(_filePath){}
	~MetaIO(){}


	// Access functions
	std::string getPath() { return FilePath; }
	

	// Other functions
	bool readFile(std::vector<std::string> &errlog)
	{
		// std::cout << "in read file..." << std::endl;

		std::string currentStr;
		std::ifstream metaFile(FilePath);
		if (metaFile.peek() == std::ifstream::traits_type::eof())
		{
			errlog.push_back(" ERROR: Meta-Data file is empty!\n");
			return false;
		}

		if ( metaFile.is_open() )
		{
			// std::cout << "file is open..." << std::endl;

			if ( !readline(metaFile, currentStr) )
			{
				errlog.push_back(" ERROR: Meta-data file not formatted correctly! {start/end section}\n");
				return false;
			}
				

			MetaData lineData;
			std::string dataStr;
			
			if ( !readline(metaFile, currentStr) )
			{
				errlog.push_back(" ERROR: Meta-data file not formatted correctly! {start/end section}\n");
				return false;
			}
			bool lastMetaDataLine;
			if ( *(currentStr.end()-1) == '.' )
				lastMetaDataLine = true;
			
			while ( !lastMetaDataLine )
			{
				currentStr.erase( remove_if(currentStr.begin(), currentStr.end(), isspace), currentStr.end() );
				std::stringstream ss(currentStr);
			    while ( std::getline(ss, dataStr, ';') ) 
			    {
					if ( !lineData.extractData(dataStr) )
					{
						errlog.push_back(" ERROR: File not formatted correctly! {in meta-data}\n");
						return false;
					}
					FileData.push_back(lineData);
			    }

			    if ( !readline(metaFile, currentStr) )
				{
					errlog.push_back(" ERROR: Meta-data file not formatted correctly! {start/end section}\n");
					return false;
				}
				if ( *(currentStr.end()-1) == '.' )
					lastMetaDataLine = true;
			}

			// deal with the last valid meta data line
			currentStr.erase( remove_if(currentStr.begin(), currentStr.end(), isspace), currentStr.end() );
			auto lastString = currentStr.substr(0, currentStr.find("."));
			std::stringstream ss(lastString);
			while ( std::getline(ss, dataStr, ';') ) 
		    {
		        dataStr.erase( remove_if(dataStr.begin(), dataStr.end(), isspace), dataStr.end() );
		        // std::cout << dataStr << std::endl;

				if ( !lineData.extractData(dataStr) )
				{
					errlog.push_back(" ERROR: File not formatted correctly! {in meta-data}\n");
					return false;
				}
				FileData.push_back(lineData);
		    }

		    if ( !readline(metaFile, currentStr) )
			{
				errlog.push_back(" ERROR: Meta-data file not formatted correctly! {start/end section\n");
				return false;
			}
			if ( currentStr != "End Program Meta-Data Code." )
			{
				errlog.push_back(" ERROR: File not formatted correctly! {in start section}\n");
				return false;
			}
		    metaFile.close();
		}
		else
		{
			errlog.push_back(" ERROR: File did not open!\n");
			return false;
		}

		// std::cout << "done..." << std::endl;

		return true;
	}


	bool readline(std::ifstream &metaFile, std::string &currentStr)
	{
		std::getline(metaFile, currentStr);
		if ( currentStr == "Start Program Meta-Data Code:" )
		{
			// if flag = true; u saw another Start -> return false;
			if ( startFlag )
				return false;
			else
				startFlag = true;
		}
		else if ( currentStr == "End Program Meta-Data Code." )
		{
			if ( startFlag )
				startFlag = false;
			else
				return false;
		}
		return true;
	}

	void print(std::vector<ConfigData> configFileData)
	{
		std::cout << "Meta-Data Metrics" << std::endl;
		for (auto metaLineData : FileData)
		{
			if ( metaLineData.getType() == "S" )
			{
				metaLineData.print(0);
			}
			if ( metaLineData.getType() == "A" )
			{
				metaLineData.print(0);
			}
			if ( metaLineData.getType() == "P" )
			{
				if ( metaLineData.getDescriptor() == "run" )
				{
					// printf("test2\n");
					auto time = configFileData[1].getRunTime();
					metaLineData.print(time);
				}
			}	
			if ( metaLineData.getType() == "I" )
			{
				// printf("test1\n");
				// std::cout << metaLineData.getDescriptor() << std::endl;
				int time;
				if ( metaLineData.getDescriptor() == "harddrive" )
				{
					// printf("test2\n");
					time = configFileData[3].getRunTime();
					metaLineData.print(time);
				}
				if ( metaLineData.getDescriptor() == "scanner" )
				{
					time = configFileData[2].getRunTime();
					metaLineData.print(time);
				}
				if ( metaLineData.getDescriptor() == "keyboard" )
				{
					time = configFileData[4].getRunTime();
					metaLineData.print(time);
				}
			}
			if ( metaLineData.getType() == "O" )
			{
				// printf("test1\n");
				// std::cout << metaLineData.getDescriptor() << std::endl;
				int time;
				if ( metaLineData.getDescriptor() == "harddrive" )
				{
					// printf("test2\n");
					time = configFileData[3].getRunTime();
					metaLineData.print(time);
				}
				if ( metaLineData.getDescriptor() == "monitor" )
				{
					time = configFileData[0].getRunTime();
					metaLineData.print(time);
				}
				if ( metaLineData.getDescriptor() == "projector" )
				{
					time = configFileData[6].getRunTime();
					metaLineData.print(time);
				}
			}
			if ( metaLineData.getType() == "M" )
			{
				if ( metaLineData.getDescriptor() == "block" )
				{
					// printf("test2\n");
					auto time = configFileData[5].getRunTime();
					metaLineData.print(time);
				}
				if ( metaLineData.getDescriptor() == "allocate" )
				{
					// printf("test2\n");
					auto time = configFileData[5].getRunTime();
					metaLineData.print(time);
				}
			}

		}
	}

};


/// Example meta-data file:
	// 1 Start Program Meta-Data Code:
	// 2 S{begin}0; A{begin}0; P{run}11; P{run}9; P{run}12;
	// 3 P{run}9; P{run}11; P({run}8; P{run}14; P{run}14; P{run}12;
	// 4 P{run}12; P{run}6; P{run}8; P{run}9; P{run}6; P{run}14;
	// 5 P{run}15; P{run}12; P{run}9; P{run}6; P{run}5; A{finish}0;
	// 6 A{begin}0; P{run}6; P{run}6; P{run}9; P{run}11; P{run}13;
	// 7 P{run}14; P{run}5; P{run}7; P{run}14; P{run}15; P{run}7;
	// 8 P{run}5; P{run}14; P{run}15; P{run}14; P{run}7; P{run}14;
	// 9 P{run}13; P{run}8; P{run}7; A{finish}0; A{begin}0; P{run}6;
	// 10 P{run}10; P{run}13; P{run}9; P{run}15; P{run}6; P{run}13;
	// 11 P{run}11; P{run}5; P{run}6; P{run}7; P{run}12; P{run}11;
	// 12 P{run}6; P{run}8; P{run}10; P{run}5; P{run}8; P{run}9; P{run}7;
	// 13 A{finish}0; S{finish}0.
	// 14 End Program Meta-Data Code.


#endif /* META_IO */