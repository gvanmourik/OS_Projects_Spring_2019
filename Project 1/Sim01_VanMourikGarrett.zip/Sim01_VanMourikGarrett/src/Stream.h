#ifndef STREAM
#define STREAM

#include <sstream>

// enum 

std::ostringstream oss;


#endif /* META_IO */