#include <string>
#include <vector>
#include <stdio.h>

bool RunHandlers(std::string configPath);
void printErrors(std::vector<std::string> &, std::string,  std::string);
